var billPanelHtml =
'';
