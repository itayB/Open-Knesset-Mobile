#define GIT_VERSION 0.0.1-4-gf927998-dirty
#define APP_VERSION 0.0.1-dirty
