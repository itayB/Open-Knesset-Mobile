#define GIT_VERSION 0.0.1-7-g9ac492f-dirty
#define APP_VERSION 0.0.1-dirty
